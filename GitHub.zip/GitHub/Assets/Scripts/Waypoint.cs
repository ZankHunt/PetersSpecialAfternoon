﻿using UnityEngine;

public class Waypoint : MonoBehaviour {
}
