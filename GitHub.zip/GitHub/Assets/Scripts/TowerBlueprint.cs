﻿using UnityEngine;

[System.Serializable]
public class TowerBlueprint {

    public GameObject prefab;
    public int moneyCost;
    public int fishCost;
}
