﻿[System.Serializable]
public class FishBlueprint {

    public string name;
    public int chance;
    public int value;

}
